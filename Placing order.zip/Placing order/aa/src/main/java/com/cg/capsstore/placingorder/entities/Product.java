package com.cg.capsstore.placingorder.entities;

import java.util.Arrays;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name="product_seq", initialValue=1000)
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="product_seq")
	private int productId;
	private String productName;
	private String productType;
	private int productsInStock;
	private double productPrice;
	private String description;
	private String productBy;
	private int merchantId;
	private String imageLink;


	public String getImageLink() {
		return imageLink;
	}

	public void setImageLink(String imageLink) {
		this.imageLink = imageLink;
	}

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public String getProductBy() {
		return productBy;
	}

	public void setProductBy(String productBy) {
		this.productBy = productBy;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public int getProductsInStock() {
		return productsInStock;
	}

	public void setProductsInStock(int productsInStock) {
		this.productsInStock = productsInStock;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(double productPrice) {
		this.productPrice = productPrice;
	}

	

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productType=" + productType
				+ ", productsInStock=" + productsInStock + ", productPrice=" + productPrice + ", description="
				+ description + ", productBy=" + productBy + ", merchantId=" + merchantId + ", imageLink=" + imageLink
				+ "]";
	}

	

	
	

	
	
}
