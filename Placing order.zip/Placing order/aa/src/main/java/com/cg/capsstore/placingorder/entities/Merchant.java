package com.cg.capsstore.placingorder.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@SequenceGenerator(name = "merchant_seq", initialValue = 3001)
@Table(name="Merchant")
public class Merchant {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "merchant_seq")
	
	private int merchantId;
	
	@Column(name="merchantname")

	private String merchantName;
	@Column(name="shopName")
	private String shopName;
	@Column(name="shopAddress")
	private String shopAddress;
	@Column(name="merchantEmail")
	private String merchantEmail;
	@Column(name="merchantMobile")
	private String merchantMobile;
	@Column(name="merchantPassword")
	
	private String merchantPassword;
	@Column(name="merchantRating")
	private double merchantRating;
	


	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getShopAddress() {
		return shopAddress;
	}

	public void setShopAddress(String shopAddress) {
		this.shopAddress = shopAddress;
	}

	public String getMerchantEmail() {
		return merchantEmail;
	}

	public void setMerchantEmail(String merchantEmail) {
		this.merchantEmail = merchantEmail;
	}

	public String getMerchantMobile() {
		return merchantMobile;
	}

	public void setMerchantMobile(String merchantMobile) {
		this.merchantMobile = merchantMobile;
	}

	public String getMerchantPassword() {
		return merchantPassword;
	}

	public void setMerchantPassword(String merchantPassword) {
		this.merchantPassword = merchantPassword;
	}

	public double getMerchantRating() {
		return merchantRating;
	}

	public void setMerchantRating(double merchantRating) {
		this.merchantRating = merchantRating;
	}

	@Override
	public String toString() {
		return "Merchant [merchantId=" + merchantId + ", merchantName=" + merchantName + ", shopName=" + shopName
				+ ", shopAddress=" + shopAddress + ", merchantEmail=" + merchantEmail + ", merchantMobile="
				+ merchantMobile + ", merchantPassword=" + merchantPassword + ", merchantRating=" + merchantRating
				+ "]";
	}

}
