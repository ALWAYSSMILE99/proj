package com.cg.capsstore.placingorder.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.capsstore.placingorder.entities.Admin;
import com.cg.capsstore.placingorder.entities.Customer;
import com.cg.capsstore.placingorder.entities.Merchant;
import com.cg.capsstore.placingorder.entities.Customer;

import com.cg.capsstore.placingorder.entities.Product;
import com.cg.capsstore.placingorder.service.IPlaceOredredProductService;

@Controller
public class PlaceOrderRest {

	@Autowired
	IPlaceOredredProductService orderproductservice;

	public IPlaceOredredProductService getOrderproductservice() {
		return orderproductservice;
	}

	public void setOrderproductservice(IPlaceOredredProductService orderproductservice) {
		this.orderproductservice = orderproductservice;
	}
	/*
	 * @GetMapping("/") public int placeorder() { OrderDetails ordetails=new
	 * OrderDetails(); ordetails.setCard(null);
	 * ordetails.setDeliveredDate(Date.valueOf(LocalDate.now())); Customer
	 * customer=orderproductservice.getCustomer(2); Product
	 * product1=orderproductservice.getProduct(1001); OrderedProduct orproduct=new
	 * OrderedProduct(); orproduct.setProductRating(0);
	 * orproduct.setProductquantity(1); orproduct.setRatingProvided(false);
	 * orproduct.setProductOrdered(product1); ordetails.setCustomer(customer);
	 * List<OrderedProduct> lop=new ArrayList<>(); lop.add(orproduct);
	 * ordetails.setProductsOrdered(lop); return
	 * orderproductservice.setOrderDetails(ordetails); }
	 */

	@RequestMapping("/welcome")
	public String showLoginPage() {
		return "LoginPage";
	}

	@RequestMapping("/showMerchantPage")
	public String showMerchantLogin() {
		return "MerchantLogin";
	}

	@RequestMapping("/showAdminPage")
	public String showAdminLogin() {
		return "Admin";
	}
	
	@RequestMapping("/showProfile")
	public String showProfile() {
		return "showProfile";
	}
	
	@RequestMapping("/Logout")
	public String logout() {
		return "MerchantLogin";
	}
	@RequestMapping("profile")
	public ModelAndView profile(@RequestParam("merchantid") int merchantId) {
		Merchant merchant = orderproductservice.showProfile(merchantId);
		return new ModelAndView("profilePage","merchant",merchant);
	}
	
	@RequestMapping("/showAllDetails{id}")
	public ModelAndView showAllDetails(@RequestParam("id") String id) {
		List list = orderproductservice.showProducts(Integer.parseInt(id));
		return new ModelAndView("merchantProducts","list",list);
	}

	@RequestMapping("/homepage")
	public String showMerchantPage() {
		return "merchantPage";
	}

	@RequestMapping("/showAddProduct")
	public ModelAndView showAddProduct() {
		Product product = new Product();
		return new ModelAndView("addProduct", "product", product);
	}

	@RequestMapping("/addProduct")
	public ModelAndView addingMerchantProduct(@RequestParam("productName") String name,
			@RequestParam("productsInStock") int stock, @RequestParam("productPrice") double price,
			@RequestParam("description") String description, @RequestParam("productBy") String productBy,
			@RequestParam("productType") String type,@RequestParam("imageLink") String link,
			@RequestParam("yourId") int merchantId) {
		String msg = null;
		if (productBy.equals("Merchant")) {
			Product product = new Product();
			product.setProductName(name);
			product.setProductPrice(price);
			product.setProductsInStock(stock);
			product.setDescription(description);
			product.setProductType(type);
			product.setProductBy(productBy);
			product.setMerchantId(merchantId);
			product.setImageLink(link);
			
			msg = orderproductservice.addProduct(product, merchantId,productBy);
		} else {
			// String msg = orderproductservice.addProduct(product, id);
		}

		return new ModelAndView("merchantPage", "msg", msg);

	}

	@RequestMapping("/showDeletePage")
	public String showDeletePage() {
		return "deleteById";
	}

	@RequestMapping("/deleteid")
	public ModelAndView deleteProductById(@RequestParam("id") int id, @RequestParam("merchantAdminid") int merchantAdminid,@RequestParam("productBy") String productBy) {
		String msg= orderproductservice.removeProduct(id, merchantAdminid,productBy);
		return new ModelAndView("merchantPage", "msg", msg);

	}

	@RequestMapping("/showDeleteByCategoryPage")
	public String showDeleteByCategoryPage() {
		return "deleteByCategory";
	}

	@RequestMapping("/deleteByCategoryPage")
	public ModelAndView deleteByCategoryPage(@RequestParam("type") String productType,@RequestParam("merchantAdminid") int merchantAdminid,@RequestParam("productBy") String productBy) {
		 String msg =orderproductservice.removeProductByCategory(productType, merchantAdminid, productBy);
		 return new ModelAndView("merchantPage", "msg", msg);
	}
	
	
	@RequestMapping("/showUpdatePage")
	public String showUpdatePage() {
		return "updatePage";
		
	}
	
	@RequestMapping("/updateProduct")
	public ModelAndView updatePage(@RequestParam("productId") int productId,
			@RequestParam("productPrice") double price,
			@RequestParam("yourId") int merchantId,
			@RequestParam("productBy") String productBy) {
		
		
		String msg = orderproductservice.updateProduct(productId, price, merchantId,productBy);
		
		return new ModelAndView("merchantPage", "msg", msg);
		
	}

	@RequestMapping("/ValidateCustomer")
	public ModelAndView ValidateCustomer(@RequestParam("login") String username,
			@RequestParam("password") String password) {
		Customer c = orderproductservice.validateDetails(username, password);
		if (c == null) {
			String msg="invalid id or password";
			return new ModelAndView("LoginPage","msg",msg);
		} else {
			return new ModelAndView("WelcomeCustomer");
		}
	}

	@RequestMapping("/ValidateMerchant")
	public ModelAndView ValidateMerchant(@RequestParam("login") String username,
			@RequestParam("password") String password) {
		Merchant m = orderproductservice.validateMerchantDetails(username, password);
		if (m == null) {
			String msg="invalid id or password";
			return new ModelAndView("LoginPage","msg",msg);
		} else {
			return new ModelAndView("merchantPage");
		}
	}

	@RequestMapping("/ValidateAdmin")
	public ModelAndView ValidateAdmin(@RequestParam("login") String username,
			@RequestParam("password") String password) {

		Admin a = orderproductservice.validateAdminDetails(username, password);
		System.out.println(a);
		if (a == null) {
			String msg="invalid id or password";
			return new ModelAndView("LoginPage","msg",msg);
		} else {
			return new ModelAndView("WelcomeAdmin");
		}
	}

}
