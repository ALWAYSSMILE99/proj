package com.cg.capsstore.placingorder.service;

import java.util.List;
import java.util.Optional;

import com.cg.capsstore.placingorder.entities.Admin;
import com.cg.capsstore.placingorder.entities.Customer;

import com.cg.capsstore.placingorder.entities.Merchant;

import com.cg.capsstore.placingorder.entities.Product;

public interface IPlaceOredredProductService {
	
	public Customer getCustomer(int id);
	
	public Product getProduct(int id);
	
	public String addProduct(Product product,int id,String productBy);
	
	public String removeProduct(int id,int merchantId,String productBy);
	
	public String removeProductByCategory(String productType,int merchantId,String productBy);
	
	public String updateProduct(int productId, double price, int merchantId,String productBy);
	
	public Customer validateDetails(String name,String password);
	
	public Merchant validateMerchantDetails(String name,String password);
	
	public Admin validateAdminDetails(String name,String password);
	
	public Merchant showProfile(int merchantId);
	
	public List showProducts(int id);
	

	
	
}
