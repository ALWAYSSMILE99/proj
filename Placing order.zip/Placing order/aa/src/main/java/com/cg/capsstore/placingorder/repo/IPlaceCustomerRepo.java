package com.cg.capsstore.placingorder.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capsstore.placingorder.entities.Customer;

public interface IPlaceCustomerRepo  extends JpaRepository<Customer, Integer>{

}
