package com.cg.capsstore.placingorder.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capsstore.placingorder.entities.Admin;
import com.cg.capsstore.placingorder.entities.Customer;
import com.cg.capsstore.placingorder.entities.Customer;
import com.cg.capsstore.placingorder.entities.Merchant;

import com.cg.capsstore.placingorder.entities.Product;
import com.cg.capsstore.placingorder.repo.IPlaceAdminRepo;
import com.cg.capsstore.placingorder.repo.IPlaceCustomerRepo;
import com.cg.capsstore.placingorder.repo.IPlaceCustomerRepo;
import com.cg.capsstore.placingorder.repo.IPlaceMerchantRepo;

import com.cg.capsstore.placingorder.repo.IPlaceProductRepo;

@Service
@Transactional
public class PlaceOrderedProductServiceImpl implements IPlaceOredredProductService {

	@Autowired
	IPlaceProductRepo placeproduct;

	@Autowired
	IPlaceCustomerRepo placecustomer;

	@Autowired
	IPlaceMerchantRepo placeMerchant;

	@Autowired
	IPlaceCustomerRepo placeCustomerDemo;

	@Autowired
	IPlaceAdminRepo placeadmin;

	public IPlaceCustomerRepo getPlaceCustomerDemo() {
		return placeCustomerDemo;
	}

	public void setPlaceCustomerDemo(IPlaceCustomerRepo placeCustomerDemo) {
		this.placeCustomerDemo = placeCustomerDemo;
	}

	public IPlaceAdminRepo getPlaceadmin() {
		return placeadmin;
	}

	public void setPlaceadmin(IPlaceAdminRepo placeadmin) {
		this.placeadmin = placeadmin;
	}

	public IPlaceMerchantRepo getPlaceMerchant() {
		return placeMerchant;
	}

	public void setPlaceMerchant(IPlaceMerchantRepo placeMerchant) {
		this.placeMerchant = placeMerchant;
	}

	public IPlaceProductRepo getPlaceproduct() {
		return placeproduct;
	}

	public void setPlaceproduct(IPlaceProductRepo placeproduct) {
		this.placeproduct = placeproduct;
	}

	public IPlaceCustomerRepo getPlacecustomer() {
		return placecustomer;
	}

	public void setPlacecustomer(IPlaceCustomerRepo placecustomer) {
		this.placecustomer = placecustomer;
	}

	public Customer getCustomer(int id) {
		return placecustomer.getOne(id);
	}

	@Override
	public Product getProduct(int id) {
		// TODO Auto-generated method stub
		return placeproduct.getOne(id);
	}

	@Override
	public String addProduct(Product product, int merchantId, String productBy) {
		// TODO Auto-generated method stub
		String result = null;
		try {
		if (productBy.equalsIgnoreCase("merchant")) {
			Optional<Merchant> merchant = placeMerchant.findById(merchantId);
			System.out.println(merchant);
			if (merchant.isPresent() == false) {
				result = "No merchant found";
			} else {
				placeproduct.save(product);
				result = "product added with Id : " + product.getProductId();
			}
		} else {
			Optional<Admin> Admin = placeadmin.findById(merchantId);
			System.out.println(Admin);
			if (Admin.isPresent() == false) {
				result = "No merchant found";
			} else {
				placeproduct.save(product);
				result = "product added with Id : " + product.getProductId();
			}
		}}
		catch(Exception e) {
			result = e.getMessage();
		}
		finally {
			return result;
		}

		

	}

	@Override
	public String removeProduct(int productId, int merchantAdminId, String productBy) {
		// TODO Auto-generated method stub
		String result = "No product found";
		// placeproduct.deleteById(productId);
		try {
		for (Product product : placeproduct.findAll()) {
			if (productBy.equals("Merchant")) {
				Optional<Merchant> merchant = placeMerchant.findById(merchantAdminId);
				if (merchant.isPresent()) {
					if (product.getProductId() == productId && product.getProductBy().equalsIgnoreCase("Merchant")
							&& product.getMerchantId() == merchantAdminId) {
						placeproduct.delete(product);
						result = " Product deleted with this ID: " + productId;
					}
				}
			}

			else {
				Optional<Admin> admin = placeadmin.findById(merchantAdminId);
				if (admin.isPresent()) {
					if (product.getProductId() == productId && product.getProductBy().equals("Admin")
							&& product.getMerchantId() == merchantAdminId) {
						placeproduct.delete(product);
						result = "Product deleted with this ID: " + productId;
					}

				}
			}

		}
		}catch (Exception e) {
			// TODO: handle exception
			result = e.getMessage();
		}finally {
			return result;
		}
		

	}

	@Override
	public String removeProductByCategory(String productType, int merchantAdminId, String productBy) {
		// TODO Auto-generated method stub
		String result = "No product found";
		try {
		for (Product product : placeproduct.findAll()) {
			if (productBy.equals("Merchant")) {
				Optional<Merchant> merchant = placeMerchant.findById(merchantAdminId);
				if (merchant.isPresent()) {
					if (product.getProductType().equalsIgnoreCase(productType)
							&& product.getProductBy().equalsIgnoreCase("Merchant")
							&& product.getMerchantId() == merchantAdminId) {
						placeproduct.delete(product);
						result = "All product deleted with this Category";
					}
				}
			}

			else {
				Optional<Admin> admin = placeadmin.findById(merchantAdminId);
				if (admin.isPresent()) {
					if (product.getProductType().equalsIgnoreCase(productType) && product.getProductBy().equals("Admin")
							&& product.getMerchantId() == merchantAdminId) {
						placeproduct.delete(product);
						result = "All product deleted with this Category";
					}

				}
			}

		}
		}catch (Exception e) {
			// TODO: handle exception
			result = e.getMessage();
		}
		finally {
			return result;
		}

		

	}

	@Override
	public String updateProduct(int productId, double price, int merchantId,String productBy) {
		// TODO Auto-generated method stub
		String result = "Product with this product id : " + productId + " not found";
		try {
		if (placeproduct.getOne(productId).getMerchantId() == merchantId&&placeproduct.getOne(productId).getProductBy().equalsIgnoreCase(productBy)) {
			Product product = placeproduct.getOne(productId);
			product.setProductPrice(price);
			placeproduct.save(product);
			result= "Product with id:+"+productId+" updated successfully with price "+price;
		}
		}catch (Exception e) {
			// TODO: handle exception
			result = e.getMessage();
		}finally {
			return result;
		}
		
		

	
	}

	@Override
	public Customer validateDetails(String name, String password) {

		Customer cust = null;
		for (Customer customer : placecustomer.findAll()) {

			if (customer.getCustomerName().equals(name) && customer.getCustomerPassword().equals(password)) {
				cust = customer;
			}

		}
		return cust;
	}

	@Override
	public Merchant validateMerchantDetails(String name, String password) {
		Merchant merch = null;
		for (Merchant merchant : placeMerchant.findAll()) {

			if (merchant.getMerchantName().equals(name) && merchant.getMerchantPassword().equals(password)) {
				merch = merchant;
			}

		}
		return merch;
	}

	@Override
	public Admin validateAdminDetails(String name, String password) {
		Admin administrator = null;

		for (Admin admin : placeadmin.findAll()) {

			if (admin.getAdminName().equals(name) && admin.getAdminPassword().equals(password)) {
				administrator = admin;
			}

		}

		return administrator;
	}

	@Override
	public Merchant showProfile(int merchantId) {
		// TODO Auto-generated method stub
		Merchant merchant = null;
		merchant = placeMerchant.getOne(merchantId);
		if (merchant != null) {
			return merchant;
		} else
			return merchant;

	}

	@Override
	public List showProducts(int id) {
		// TODO Auto-generated method stub
		List<Product> list = placeproduct.findAll();
		ArrayList<Product> merchantProducts = new ArrayList<>();
		for (Product product : list) {
			if (product.getMerchantId() == id) {
				merchantProducts.add(product);
			}
		}

		return merchantProducts;
	}

}
