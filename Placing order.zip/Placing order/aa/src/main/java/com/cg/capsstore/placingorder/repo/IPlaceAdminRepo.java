package com.cg.capsstore.placingorder.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capsstore.placingorder.entities.Admin;


public interface IPlaceAdminRepo extends JpaRepository<Admin, Integer> {

}
