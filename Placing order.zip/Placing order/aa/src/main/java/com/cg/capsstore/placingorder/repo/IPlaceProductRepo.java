package com.cg.capsstore.placingorder.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capsstore.placingorder.entities.Product;

public interface IPlaceProductRepo extends JpaRepository<Product, Integer>{

}
