package com.cg.capsstore.placingorder.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capsstore.placingorder.entities.Merchant;

public interface IPlaceMerchantRepo extends JpaRepository<Merchant, Integer>{

}
